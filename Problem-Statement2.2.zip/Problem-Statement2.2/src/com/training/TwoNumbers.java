package com.training;

public class TwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1, n = 13, firstTerm = 1, secondTerm = 3;
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(firstTerm + ", ");

	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;

	      i++;
	}

	}
}
